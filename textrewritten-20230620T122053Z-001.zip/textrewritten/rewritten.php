<?php
function Rewritte($textogeral){
    $palavrastext =explode(" ",$textogeral );
    $textoreescrito="";
    $sinonimos = fopen("BaseSinonimos.csv", "r");
    $row = 0;
    $palavras =[];
    while ($line = fgetcsv($sinonimos, 1000, ",")) {
        if ($row++ == 0) {
            continue;
        }
        $data = explode( ";" ,$line[0]);
        array_push($palavras, $data);
        //$palavras[] .= $data;

    }


        foreach($palavrastext as $searsh){
            $rewritten =1;
            $sortnumber=rand(1,4);
            if($sortnumber == 3){
                if($rewritten == 1){
                    foreach($palavras as $conjuntosinonimos){
                        $rewritten= 3;
                        $sinonimosdata = array_search($searsh, $conjuntosinonimos);
                        $sinarray =in_array($searsh, $conjuntosinonimos);  
                        $replace = 0 ;
                        if($sinarray == 1){
                            $sinonimosarraycount= count($conjuntosinonimos);
                            if($replace == 0){
                                if($sinonimosarraycount < 0){
                                    $textoreescrito .= " ". $conjuntosinonimos[(rand(0, ($sinonimosarraycount -2)))];
                                }
                                else{
                                    $textoreescrito .="";
                                }
                                $replace=1;
                            }
                            else{
                                $textoreescrito .="";
                            }
                            }
                        }
                    }
                    else{

                    }
                }
            else{
                $textoreescrito .= " ". $searsh;
            }
        }
        return $textoreescrito;

}