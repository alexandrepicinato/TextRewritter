<?php
include("rewritten.php");
$texto='A produção independente é a maneira que as mulheres contam para engravidar sem a necessidade de um parceiro do sexo masculino  Ela é possível graças ao avanço das técnicas de reprodução assistida  Com a ajuda da ciência, tanto mulheres que não possuem parceiros, quanto casais homoafetivos podem realizar o sonho de ter filhos a partir de uma produção independente  Mais à frente falaremos sobre cada um desses casos';
$rewritedtext = Rewritte($texto);
echo json_encode([
    "originaltext" =>$texto,
    "rewritedtext" =>$rewritedtext
]);